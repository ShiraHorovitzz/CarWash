public class SUV extends Vehicle{
    public SUV(int licence, VehicleWasher vehicleWasher) {
        super(licence, vehicleWasher);
    }
}
