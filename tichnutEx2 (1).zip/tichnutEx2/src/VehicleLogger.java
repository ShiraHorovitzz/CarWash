import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class VehicleLogger {
    PrintWriter pw;
    Scanner s;
    long time;

    public VehicleLogger(File file){
        try{
            pw = new PrintWriter(file);
            s = new Scanner(file);
        }catch (IOException e){}

        time = System.currentTimeMillis();
}

    public void write(Vehicle vehicle, String str){
        pw.println(str+", "+(System.currentTimeMillis()-time)+" Vehicle Type: "+ vehicle.getClass().getSimpleName()+" Licence Number: "+ vehicle.getLicence());
    }
    public void closeWrite(){
        pw.close();
    }

    public String read(){
        StringBuffer sb = new StringBuffer();

        while (s.hasNext()){
            sb.append(s.nextLine());
        }
        return sb.toString();
    }





}

