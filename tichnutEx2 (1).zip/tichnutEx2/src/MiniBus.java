//Tehila Menasheof 206089195, Shira Horovitz 302642665
public class MiniBus extends Vehicle{
    public MiniBus(int licence, VehicleWasher vehicleWasher) {
        super(licence, vehicleWasher);
    }
}
