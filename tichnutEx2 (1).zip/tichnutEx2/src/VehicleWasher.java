import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;



public class VehicleWasher {
    LinkedList<Vehicle> carsInQueue = new LinkedList<>();
    ArrayList<Vehicle> carsInWasher = new ArrayList<>();
    int washerMachines, carsLeft;
    Object washerFree = new Object();
    VehicleLogger vl;

    Long startTime;
    long lineTime, washTime, avgTime;


    LinkedList<Truck> trucksAfterWasher = new LinkedList<>();
    LinkedList<SUV> SUVsAfterWasher = new LinkedList<>();
    LinkedList<MiniBus> MiniBusAfterWasher = new LinkedList<>();
    LinkedList<Car> CarAfterWasher = new LinkedList<>();

    public VehicleWasher(int washingMachines, int carsLeft, File file, long washTime, long lineTime){
        this.washerMachines = washingMachines;
        this.carsLeft = carsLeft;

        vl = new VehicleLogger(file);

        startTime = System.currentTimeMillis();
        this.lineTime = lineTime;
        this.washTime = washTime;
    }

    public void getToLine(Vehicle vehicle) throws InterruptedException{
        synchronized(carsInQueue){
            carsInQueue.add(vehicle);
            System.out.println("in line: "+vehicle);
            Thread.sleep(lineTime);
            vl.write(vehicle, "Get in line");
        }
    }

    public void getToWash() throws InterruptedException{//wants to get to the washing machine
        Vehicle temp;
        synchronized(this){
            while(!isFree()){//checks if there's a free space in the machine
                wait();
            }
            acquire();
        }
     
        synchronized(carsInQueue){
             temp = carsInQueue.removeFirst();
             System.out.println("in wash: "+temp);
        }
        vl.write(temp, "In wash");

        Thread.sleep(washTime);
        //assigning to the relevnt queue
        if (temp.getClass().getSimpleName().equals("Car"))
            synchronized(CarAfterWasher){
            CarAfterWasher.add((Car) temp);}
        else if (temp.getClass().getSimpleName().equals("Truck"))
        synchronized(trucksAfterWasher){
            trucksAfterWasher.add((Truck) temp);}
        else if (temp.getClass().getSimpleName().equals("SUV"))
        synchronized(SUVsAfterWasher){
            SUVsAfterWasher.add((SUV) temp);}
        else if (temp.getClass().getSimpleName().equals("MiniBus"))
        synchronized(MiniBusAfterWasher){
            MiniBusAfterWasher.add((MiniBus) temp);}


        System.out.println("finish: "+temp);
        temp.setFinishTime(System.currentTimeMillis()-startTime);
        vl.write(temp, "Finished");


        decrease();

        if(isFinished()){
            System.out.println("Cars: "+CarAfterWasher);
            System.out.println("Trucks "+trucksAfterWasher);
            System.out.println("MiniBus "+ MiniBusAfterWasher);
            System.out.println("SUVS "+SUVsAfterWasher);

            vl.closeWrite();

            printAvg(CarAfterWasher, "Cars");
            printAvg(trucksAfterWasher, "Truck");
            printAvg(SUVsAfterWasher, "SUV");
            printAvg(MiniBusAfterWasher, "MiniBus");


        }
        release();
        synchronized(this){
            notifyAll();
        }

    }

    public synchronized boolean isFinished(){
        return carsLeft==0;
    }

    public synchronized void  decrease(){
        carsLeft--;
    }

    public void acquire(){//takes an open place in the washer mahine
        synchronized(washerFree){
            washerMachines--;
        }

    }
    public void release(){//realase a place in the washer mahine
        synchronized(washerFree){
            washerMachines++;
        }
    }

    public boolean isFree(){//checks if there's a free place
        boolean answer;
        synchronized(washerFree){
         answer = washerMachines>0;
        }
        return answer;
    }

    public void printAvg(LinkedList<? extends Vehicle> vehicles, String type){
        vehicles.forEach(v->{
            avgTime+=v.getFinishTime();
        });
        System.out.println("avg time for "+type+" "+avgTime/vehicles.size());
        avgTime = 0;

    }


































//     Object b = new Object();

//     AtomicInteger washingMachines = new AtomicInteger(2), hasFinish = new AtomicInteger(0);

    
//     VehicleLogger vl = new VehicleLogger(new File("log.txt"));
//     long timeLine, timeWash;

//     public VehicleWasher(double timeToGetToLine, double timeToGetToWash) {
//         this.timeLine = (long) timeToGetToLine;
//         this.timeWash = (long) timeToGetToWash;

//     }


//     public void getInQueue(Vehicle vehicle) throws InterruptedException {
//         synchronized (carsInQueue) {
//             carsInQueue.addLast(vehicle);
//             System.out.println(vehicle);
//             vl.write(vehicle, "in line");
//             Thread.sleep(800);
//         }
//         getInWash();
//     }

//     public void getInWash() throws InterruptedException {
//         Vehicle temp;

//         while (washingMachines.get() <= 0) {
//             synchronized (b) {
//                 wait();
//             }
//         }
//         washingMachines.decrementAndGet();

//         synchronized (carsInQueue) {
//             temp = carsInQueue.getFirst();
//             carsInQueue.removeFirst();
//             System.out.println(temp);

//         }
//         synchronized (carsInWasher) {
//             vl.write(temp, "in wash");
//             carsInWasher.add(temp);
//         }
//         Thread.sleep(3000);
//         temp.setFinishTime(System.currentTimeMillis());

//         if (temp.getClass().getSimpleName().equals("Car"))
//             CarAfterWasher.add((Car) temp);
//         if (temp.getClass().getSimpleName().equals("Truck"))
//             trucksAfterWasher.add((Truck) temp);
//         if (temp.getClass().getSimpleName().equals("SUV"))
//             SUVsAfterWasher.add((SUV) temp);
//         if (temp.getClass().getSimpleName().equals("MiniBus"))
//             MiniBusAfterWasher.add((MiniBus) temp);
//         washingMachines.incrementAndGet();
//         hasFinish.getAndDecrement();
//         vl.write(temp, "finished");

//         synchronized (b) {
//             b.notifyAll();
//         }
//         if (hasFinish.get() == 0) {
//             System.out.println("finissssssdfkgalsdfjgkhasfjkghakjsfnga");
//             avgTime(CarAfterWasher, "Car");
//             avgTime(SUVsAfterWasher, "SUV");
//             avgTime(trucksAfterWasher, "Truck");
//             avgTime(MiniBusAfterWasher, "MiniBus");
//             vl.closeWrite();
//         }

//     }


//     public void avgTime(LinkedList<? extends Vehicle> list, String name_of_list) {
//         list.forEach(t -> {
//             avg += t.getFinishTime();
//         });

//         if (list.size() > 0)
//             System.out.println(name_of_list + "  " + avg / list.size());
//     }


}
