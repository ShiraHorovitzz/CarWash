public class Vehicle implements Runnable {//abstract
    private int licence;
    private long finishTime;
    VehicleWasher vehicleWasher;

    public Vehicle(int licence, VehicleWasher vehicleWasher) {
        this.licence = licence;
        this.vehicleWasher = vehicleWasher;
    }

    @Override
    public void run() {
        try {
            vehicleWasher.getToLine(this);
            vehicleWasher.getToWash();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
   
    }



    @Override
    public String toString(){
        return "type: "+this.getClass().getSimpleName()+ " Licence: "+licence;
    }

    public int getLicence() {
        return licence;
    }
    public void setFinishTime(long finishTime) {
        this.finishTime = finishTime;
    }

    public long getFinishTime() {
        return finishTime;
    }
}
