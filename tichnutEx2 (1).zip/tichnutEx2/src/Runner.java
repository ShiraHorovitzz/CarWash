//Tehila Menasheof 206089195, Shira Horovitz 302642665
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        File f = new File("log.txt");
        long s =(long) (-(Math.log(Math.random()) / 1.5) * 1000);
        long s1 =(long) (-(Math.log(Math.random()) / 3) * 1000);

        System.out.println(s);
        System.out.println(s1);


        System.out.println("how many cars will arrive");
        int carsToArrive = scan.nextInt();
        System.out.println("how many washing machines in car wash");
        int washingMachine = scan.nextInt();

        VehicleWasher firstMachine = new VehicleWasher(washingMachine, carsToArrive, f,s,s1);

        ArrayList<Thread> listOfCars = new ArrayList<>();

        for (int i = 0; i < carsToArrive; i++) {
            int vehicleType = (int) (Math.random() * 4) + 1;
            int vehicleLicence = (int) (Math.random() * 100 + 1);

            if (vehicleType == 1)
                listOfCars.add(new Thread(new Car(vehicleLicence, firstMachine)));
            else if (vehicleType == 2)
                listOfCars.add(new Thread(new MiniBus(vehicleLicence, firstMachine)));
            else if (vehicleType == 3)
                listOfCars.add(new Thread(new Truck(vehicleLicence, firstMachine)));
            else if (vehicleType == 4)
                listOfCars.add(new Thread(new SUV(vehicleLicence, firstMachine)));

        }

        listOfCars.forEach(t -> {
            t.start();
        });

    }
}
