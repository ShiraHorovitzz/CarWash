//Tehila Menasheof 206089195, Shira Horovitz 302642665
public class Car extends Vehicle{
    public Car(int licence, VehicleWasher vehicleWasher) {
        super(licence, vehicleWasher);
    }
}
