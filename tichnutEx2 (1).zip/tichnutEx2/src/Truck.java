public class Truck extends Vehicle{
    public Truck(int licence, VehicleWasher vehicleWasher) {
        super(licence, vehicleWasher);
    }
}
